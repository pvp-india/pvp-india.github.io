# Plugins

Install plugins only through your host's supported plugin manager or by downloading them from their official sources.

## Java + Bedrock cross-play
- **Geyser** bridges Bedrock clients to a Java server.
- **Floodgate** is optional and can allow Bedrock players to authenticate without a Java Edition account.
- Official instructions: https://geysermc.org/wiki/geyser/setup/

Restart the server after installing plugins. Check the console for errors and use the address/port supplied by the host for Bedrock connections.

Do not download random plugin JARs from untrusted file-sharing sites.
