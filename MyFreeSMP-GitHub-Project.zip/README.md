# MyFreeSMP — Free Minecraft Server Setup

This repository stores setup notes and configuration templates for **MyFreeSMP**.
It does not itself host a live Minecraft server. GitHub Pages cannot run Minecraft server software.

## Target setup
- Java Edition server
- Paper server software
- Bedrock cross-play through Geyser (and optionally Floodgate)
- Preferred region: India
- Budget: ₹0
- Desired RAM: 6 GB (free plans may provide less)
- Desired uptime: 24/7 (free hosts generally cannot guarantee this)

## Quick start
1. Create a server at a free Minecraft host, such as [PowerupStack](https://www.powerupstack.com/games/minecraft/free?region=AS-IN) or [Aternos](https://aternos.org/).
2. Name it `MyFreeSMP` if the host supports a custom name.
3. Select Java Edition and Paper, then select an India region if available.
4. Start the server and accept the EULA in the hosting panel if prompted.
5. Install Geyser using the host's plugin manager or follow the [official Geyser setup guide](https://geysermc.org/wiki/geyser/setup/).
6. Add Floodgate only if you want Bedrock players to join without owning a Java Edition account, and configure it according to the official guide.
7. Copy the Java address and Bedrock address/port shown in the hosting panel. Test both editions.

## Important limitations
- Free hosting RAM, regional capacity, and uptime vary. Confirm the current plan before relying on it.
- GitHub repositories and GitHub Pages do not run a persistent Minecraft game server.
- Do not expose passwords, API tokens, private keys, or server secrets in this repository.
- Follow the host's terms and Minecraft's EULA.

## Files
- `server.properties.example` — example settings for a small survival server.
- `plugins/README.md` — notes for installing Paper plugins and cross-play.
- `docs/hosting-options.md` — hosting selection checklist.
