# Hosting options checklist

Before creating MyFreeSMP, confirm:

- [ ] Free plan does not require payment details
- [ ] India or nearby region is available
- [ ] Paper is supported
- [ ] Enough RAM for your player count and plugins (6 GB is the target, not guaranteed)
- [ ] Cross-play plugin installation is permitted
- [ ] Server address and Bedrock port are available
- [ ] Backups/export are possible
- [ ] Idle shutdown and uptime policy are understood

Potential starting points:
- PowerupStack India-region page: https://www.powerupstack.com/games/minecraft/free?region=AS-IN
- Aternos: https://aternos.org/
- Geyser setup guide: https://geysermc.org/wiki/geyser/setup/

Free hosts can impose RAM limits, queues, idle shutdown, or regional capacity limits. Verify current details on the provider's own site.
